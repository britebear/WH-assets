# Woof House Fitness Brand Assets

**Copyright © Woof House Fitness. All rights reserved.**

These files are provided solely for official Woof House Fitness communications and marketing.
No license is granted for third‑party reuse.

## Files
- `woofhouse_logo_transparent_640.png` — transparent PNG for light backgrounds (use ~180px display width in email signatures).
- `woofhouse_logo_whitebg_640.png` — white background PNG for dark-mode safety.

### Recommended alt text
Woof House Fitness logo — purple shield with dog silhouette and stacked wordmark.
